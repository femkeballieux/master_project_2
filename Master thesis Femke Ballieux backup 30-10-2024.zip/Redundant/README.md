# observatory_thesis_style
Unofficial Leiden Observatory thesis style
